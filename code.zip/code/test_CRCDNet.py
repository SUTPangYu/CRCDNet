import torch
import torch.nn.functional as F

import numpy as np
import pdb, os, argparse
from scipy import misc
import imageio
import time
import torch.fx
from model.GeleNet_models import GeleNet
from data import test_dataset

parser = argparse.ArgumentParser()
parser.add_argument('--testsize', type=int, default=352, help='testing size')
opt = parser.parse_args()

dataset_path = 'E:/Dataset/VT5000/Test'

model = GeleNet()
model.load_state_dict(torch.load('./models/GeleNet/GeleNet.pth'))

model.cuda()
model.eval()

test_datasets = ['./Result/VT5000/complete+FPN3']
#test_datasets = ['EORSSD','ORSSD','ors-4199']

for dataset in test_datasets:
    save_path = './models/GeleNet/' + dataset + '/'
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    image_root = dataset_path  + '/RGBT/'
    print(dataset)
    gt_root = dataset_path  + '/GT/'
    test_loader = test_dataset(image_root, gt_root, opt.testsize)
    time_sum = 0
    for i in range(test_loader.size):
        print(i)
        image, gt, name = test_loader.load_data()
        gt = np.asarray(gt, np.float32)
        gt /= (gt.max() + 1e-8)
        image = image.cuda()
        time_start = time.time()
        # res, sal_sig, res1, sal_sig1, res2, sal_sig2, res3, sal_sig3, res4, sal_sig4,ranking_map = model(image)
        res, sal_sig,x1,x1_add,x2,x2_add,x3,x3_add,x4,x4_add = model(image)
        time_end = time.time()
        time_sum = time_sum+(time_end-time_start)

        ######## ranking1
        res1 = sal_sig
        res1 = F.upsample(res1, size=gt.shape, mode='bilinear', align_corners=False)
        res1 = res1.sigmoid().data.cpu().numpy().squeeze()
        res1 = (res1 - res1.min()) / (res1.max() - res1.min() + 1e-8)
        res1 = (res1 * 255).astype(np.uint8)  # 先缩放再转换‌:ml-citation{ref="1,2" data="citationList"}
        imageio.imsave(save_path  +name[:-4]+'.png', res1)

        # ranking_map = F.upsample(ranking_map, size=gt.shape, mode='bilinear', align_corners=False)
        # ranking_map = ranking_map.data.cpu().numpy().squeeze()
        # ranking_map = (ranking_map * 255).astype(np.uint8)  # 先缩放再转换‌:ml-citation{ref="1,2" data="citationList"}
        # imageio.imsave(save_path + name[:-4] + '.png', ranking_map)

        if i == test_loader.size-1:
            print('Running time {:.5f}'.format(time_sum/test_loader.size))
            print('FPS {:.5f}'.format(test_loader.size / time_sum))

