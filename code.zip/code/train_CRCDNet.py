import cv2
import torch
import torch.nn.functional as F
import torch.nn as nn
import torch.fx
import imageio
from torch.autograd import Variable
from model.pvtv2 import pvt_v2_b2
import numpy as np
import pdb, os, argparse
from datetime import datetime

from model.GeleNet_models import GeleNet
from data import get_loader
from utils import clip_gradient, adjust_lr

import pytorch_iou

# torch.cuda.set_device(0)
parser = argparse.ArgumentParser()
parser.add_argument('--epoch', type=int, default=45, help='epoch number')
parser.add_argument('--lr', type=float, default=1e-4, help='learning rate')
parser.add_argument('--batchsize', type=int, default=4, help='training batch size')
parser.add_argument('--trainsize', type=int, default=352, help='training dataset size')
parser.add_argument('--clip', type=float, default=0.5, help='gradient clipping margin')
parser.add_argument('--decay_rate', type=float, default=0.1, help='decay rate of learning rate')
parser.add_argument('--decay_epoch', type=int, default=30, help='every n epochs decay learning rate')
opt = parser.parse_args()

# build models
model = GeleNet()

model.cuda()
params = model.parameters()
optimizer = torch.optim.Adam(params, opt.lr)
#
# image_root = './dataset/train_dataset/ORSSD/train/image/'
# gt_root = './dataset/train_dataset/ORSSD/train/GT/'
# image_root = 'E:/Dataset/ASSR_saliency/images/train/'
# gt_root = 'E:/Dataset/ASSR/gt/train/'
# image_root = 'E:/Dataset/ASSRenhance/images/train/'
# gt_root = 'E:/Dataset/ASSRenhance/gt/train/'
image_root='E:/Dataset/VT5000/Train/RGBT/'
gt_root='E:/Dataset/VT5000/Train/GT/'
train_loader = get_loader(image_root, gt_root, batchsize=opt.batchsize, trainsize=opt.trainsize,num_workers=0)
total_step = len(train_loader)

MSE = torch.nn.MSELoss()
CE =  torch.nn.BCEWithLogitsLoss()
IOU = pytorch_iou.IOU(size_average = True)
KLL= torch.nn.KLDivLoss()
criterion = nn.CrossEntropyLoss()
count=0

def your_function():
    global count  # 声明使用全局变量
    count += 1    # 每次执行此行时计数 +1




def tensor_entropy(tensor):
    """计算N维张量的信息熵（支持PyTorch/CUDA张量）"""
    # 自动检测数据类型并转换
    if isinstance(tensor, torch.Tensor):
        tensor = tensor.detach().cpu().numpy()
    elif not isinstance(tensor, np.ndarray):
        tensor = np.array(tensor)

    # 展平并计算概率分布
    flattened = tensor.flatten()
    total = len(flattened)
    unique, counts = np.unique(flattened, return_counts=True)
    probabilities = counts / total

    # 计算熵（避免log(0)）
    entropy = -np.mean(probabilities * np.log2(probabilities, where=(probabilities > 0)))
    return entropy

def train(train_loader, model, optimizer, epoch):
    glp=45/4*2500
    model.train()
    if __name__ == '__main__':
     for i, pack in enumerate(train_loader, start=1):
        # torch.cuda.empty_cache()
        your_function()
        optimizer.zero_grad()
        images, gts = pack
        images = Variable(images)
        gts = Variable(gts)
        images = images.cuda()
        gts = gts.cuda()
        current_value=count/glp

        sal,sal_sig,x1,x1_add,x2,x2_add,x3,x3_add,x4,x4_add = model(images)

        th=torch.mean(sal_sig)
        loss_map= torch.abs(sal_sig - th)
        mul=2**(1-current_value)
        loss_map=torch.pow(loss_map,mul)

        loss_kd=pow(th,mul)-torch.mean(loss_map)
        # ryn_op=ryn**torch.tensor([zjw,zjw,zjw,zjw],device=0).view(4,1,1,1)
        # ryn_op_a=torch.exp(-ryn_op)

        # ryn_op_op=torch.mean(ryn_op)

        loss_x3=tensor_entropy(x3)
        loss_x4=tensor_entropy(x4)
        # loss = CE(sal, gts) + IOU(sal_sig, gts)+MSE(x1,x1_add)+MSE(x2,x2_add)+MSE(x3,x3_add)+MSE(x4,x4_add)+0.05*loss_kd+loss_x3+loss_x4
        loss = CE(sal, gts) + IOU(sal_sig, gts)
        # loss = CE(sal, gts) + IOU(sal_sig, gts)
        loss.backward()

        clip_gradient(optimizer, opt.clip)
        optimizer.step()


        print(
             '{} Epoch [{:03d}/{:03d}], Step [{:04d}/{:04d}], Learning Rate: {}, Loss: {:.4f}' .
                  format(datetime.now(), epoch, opt.epoch, i, total_step,
                        opt.lr * opt.decay_rate ** (epoch // opt.decay_epoch), loss.data))


    save_path = 'models/GeleNet/'

    if not os.path.exists(save_path):
        os.makedirs(save_path)
    if (epoch+1) % 5 == 0:
        torch.save(model.state_dict(), save_path + 'GeleNet.pth' + '.%d' % epoch, _use_new_zipfile_serialization=False)

print("Let's go!")


for epoch in range(1, opt.epoch):
    adjust_lr(optimizer, opt.lr, epoch, opt.decay_rate, opt.decay_epoch)
    train(train_loader, model, optimizer, epoch)
