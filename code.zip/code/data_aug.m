clear;
clc;
close all;

imPath = 'E:\Dataset\VT5000\Train\RGBT_new\';
GtPath = 'E:\Dataset\VT5000\Train\gt_new\';

images = dir([GtPath,'*.png']);
imagesNum = length(images);

for i = 1 : imagesNum
    i
    im_name = images(i).name(1:end-4);

    gt = imread(fullfile(GtPath, [im_name '.png']));
    im = imread(fullfile(imPath, [im_name '.jpg']));
      
    im_1 = imrotate(im,90); 
    gt_1 = imrotate(gt,90); 
    imwrite(im_1, fullfile(imPath, [im_name '_90.jpg']));
    imwrite(gt_1, fullfile(GtPath, [im_name '_90.png']));

    im_2 = imrotate(im, 180); 
    gt_2 = imrotate(gt, 180); 
    imwrite(im_2, fullfile(imPath, [im_name '_180.jpg']));
    imwrite(gt_2, fullfile(GtPath, [im_name '_180.png']));

    im_3 = imrotate(im, 270); 
    gt_3 = imrotate(gt, 270); 
    imwrite(im_3, fullfile(imPath, [im_name '_270.jpg']));
    imwrite(gt_3, fullfile(GtPath, [im_name '_270.png']));
    
    fl_im=im;
    fl_gt=gt;
%     fl_im = fliplr(im);
    for k = 1:size(im, 3) % ��ÿ��ͨ������
    fl_im(:, :, k) = fliplr(im(:, :, k));
    end
     for k = 1:size(gt, 3) % ��ÿ��ͨ������
    fl_gt(:, :, k) = fliplr(gt(:, :, k));
    end
    imwrite(fl_im, fullfile(imPath, [im_name '_fl.jpg']));
    imwrite(fl_gt, fullfile(GtPath, [im_name '_fl.png'])); 
    
    im_1 = imrotate(fl_im,90); 
    gt_1 = imrotate(fl_gt,90);
    imwrite(im_1, fullfile(imPath, [im_name '_fl90.jpg']));
    imwrite(gt_1, fullfile(GtPath, [im_name '_fl90.png']));
    
    im_2 = imrotate(fl_im, 180); 
    gt_2 = imrotate(fl_gt, 180); 
    imwrite(im_2, fullfile(imPath, [im_name '_fl180.jpg']));
    imwrite(gt_2, fullfile(GtPath, [im_name '_fl180.png']));

    im_3 = imrotate(fl_im, 270); 
    gt_3 = imrotate(fl_gt, 270); 
    imwrite(im_3, fullfile(imPath, [im_name '_fl270.jpg']));
    imwrite(gt_3, fullfile(GtPath, [im_name '_fl270.png']));

end
